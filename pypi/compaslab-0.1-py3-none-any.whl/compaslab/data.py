datadir = 'https://raw.githubusercontent.com/ml4sts/outreach-compas/main/data/'

files = {'compas.csv':'full data from propublica',
        'compas_c.csv':'cleaned as propublica instructions',
        'compas_cq.csv':'cleaned and quantized'
